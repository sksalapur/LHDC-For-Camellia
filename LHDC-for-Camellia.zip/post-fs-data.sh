#!/system/bin/sh
MODDIR=${0%/*}

setenforce 0 2>/dev/null

# Mount patched AospBluetoothResOverlay.apk to set LHDC priority to 8002/8001
OVERLAY_TARGET="/product/overlay/AospBluetoothResOverlay.apk"
OVERLAY_PATCHED="$MODDIR/work/AospBluetoothResOverlay.apk"
if [ -f "$OVERLAY_PATCHED" ] && [ -f "$OVERLAY_TARGET" ]; then
    mount --bind "$OVERLAY_PATCHED" "$OVERLAY_TARGET"
fi

# Note: MiuiBluetooth.apk is intentionally NOT mounted in post-fs-data.sh.
# Mounting here causes Android PackageManagerService to drop com.xiaomi.bluetooth on boot due to signature check.
# It is mounted late in service.sh after PMS scans the authentic system APK.

# Directory bind-mount for APEX lib64 (includes JNI, shim, and all V5 libs)
APEX_LIB64="$MODDIR/apex_lib64"
if [ -d "$APEX_LIB64" ]; then
    mount -o bind "$APEX_LIB64" /apex/com.android.btservices/lib64 2>/dev/null || true
    for TARGET in /apex/com.android.btservices@*/lib64; do
        if [ -d "$TARGET" ]; then
            mount -o bind "$APEX_LIB64" "$TARGET" 2>/dev/null || true
        fi
    done
fi

# Individual file mounts as fallback
JNI_PATCHED="$MODDIR/work/libbluetooth_jni.so"
if [ -f "$JNI_PATCHED" ]; then
    for TARGET in /apex/com.android.btservices/lib64/libbluetooth_jni.so /apex/com.android.btservices@*/lib64/libbluetooth_jni.so; do
        if [ -f "$TARGET" ]; then
            mount --bind "$JNI_PATCHED" "$TARGET" 2>/dev/null || true
        fi
    done
fi

SHIM_PATCHED="$MODDIR/system/lib64/liblhdcBT_enc.so"
if [ -f "$SHIM_PATCHED" ]; then
    mount --bind "$SHIM_PATCHED" /system/lib64/liblhdcBT_enc.so 2>/dev/null || true
    for TARGET in /apex/com.android.btservices/lib64/liblhdcBT_enc.so /apex/com.android.btservices@*/lib64/liblhdcBT_enc.so; do
        if [ -f "$TARGET" ]; then
            mount --bind "$SHIM_PATCHED" "$TARGET" 2>/dev/null || true
        fi
    done
fi

# Bind-mount patched framework-bluetooth.jar before zygote loads BOOTCLASSPATH
# so BluetoothCodecConfig.getCodecName() & BluetoothCodecType.getCodecName() expose
# the true LHDC codec name on vendor codec slot 10/12 without hiddenapi blocking.
FW_BT_PATCHED="$MODDIR/work/framework-bluetooth.jar"
if [ -f "$FW_BT_PATCHED" ]; then
    chmod 0644 "$FW_BT_PATCHED" 2>/dev/null || true
    chcon u:object_r:system_file:s0 "$FW_BT_PATCHED" 2>/dev/null || true
    for TARGET in /apex/com.android.btservices/javalib/framework-bluetooth.jar /apex/com.android.btservices@*/javalib/framework-bluetooth.jar; do
        if [ -f "$TARGET" ]; then
            mount --bind "$FW_BT_PATCHED" "$TARGET" 2>/dev/null || true
        fi
    done
fi
